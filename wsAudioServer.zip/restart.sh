#!/bin/bash

# Kill the existing Node.js process
pkill node

# Wait for a moment to ensure that the process is killed
sleep 2

# Start the Node.js server again
./start.sh

