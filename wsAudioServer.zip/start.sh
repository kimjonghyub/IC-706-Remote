#!/bin/bash

# Change directory to where your server.js file is located
cd /home/DS3DND/wsAudioServer

# Start the Node.js server
node server.js
